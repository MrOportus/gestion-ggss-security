const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-dcX5ZQjS.js","assets/index-BDjiBZsY.js","assets/index-BhkeuDA5.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BDjiBZsY.js";const _=p("App",{web:()=>r(()=>import("./web-dcX5ZQjS.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
