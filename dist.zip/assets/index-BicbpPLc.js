const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CK2JtquX.js","assets/index-DeYViQI9.js","assets/index-BhkeuDA5.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-DeYViQI9.js";const _=p("App",{web:()=>r(()=>import("./web-CK2JtquX.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
